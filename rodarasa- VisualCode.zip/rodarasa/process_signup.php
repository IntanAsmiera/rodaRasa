<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Roda Rasa</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: relative;
            z-index: 2;
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
        }
        
        /* Disabled navigation items */
        nav ul li a.disabled {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            cursor: default;
            opacity: 0.7;
            pointer-events: none;
        }
        
        /* Enabled navigation items */
        nav ul li a:not(.disabled) {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        
        nav ul li a:not(.disabled):hover {
            border-bottom: 2px solid white;
        }
        
        .hero {
            height: 100vh;
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), 
                      url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            text-align: center;
        }

        .form-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
            margin: 0 auto;
        }
        
        .form-container h2 {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 1.2rem;
            box-sizing: border-box;
        }
        
        button[type="submit"] {
            width: 100%;
            padding: 1rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        button[type="submit"]:hover {
            background-color: #c0392b;
        }
        
        .signup-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #666;
        }
        
        .signup-link a {
            color: #e74c3c;
            font-weight: bold;
            text-decoration: none;
        }

        .success-message {
            color: #4CAF50;
            margin-bottom: 15px;
            padding: 10px;
            background: #eeffee;
            border: 1px solid #ccffcc;
            border-radius: 4px;
            text-align: center;
        }

        .error-message {
            color: #e74c3c;
            margin-bottom: 15px;
            padding: 10px;
            background: #ffeeee;
            border: 1px solid #ffcccc;
            border-radius: 4px;
            text-align: center;
        }
        
        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            position: relative;
            z-index: 2;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="#" class="disabled">Home</a></li>
                <li><a href="#" class="disabled">Information</a></li>
                <li><a href="#" class="disabled">Food Truck</a></li>
                <li><a href="signup.php">Sign Up</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <section class="hero">
        <div class="form-container">
            <h2>Admin Login</h2>
            
            <?php if (isset($_SESSION['registration_success'])): ?>
                <div class="success-message">
                    <?php echo htmlspecialchars($_SESSION['success_message']); ?>
                </div>
                <?php 
                unset($_SESSION['registration_success']);
                unset($_SESSION['success_message']);
            endif; ?>
            
            <?php if (isset($_SESSION['login_errors'])): ?>
                <div class="error-message">
                    <?php foreach ($_SESSION['login_errors'] as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
                <?php unset($_SESSION['login_errors']); ?>
            <?php endif; ?>
            
            <form action="process_login.php" method="POST">
                <div>
                    <input type="email" id="email" name="email" placeholder="Email Address" required 
                           value="<?php echo htmlspecialchars($_SESSION['login_email'] ?? ''); ?>">
                </div>
                
                <div>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                
                <button type="submit">Login</button>
            </form>
            
            <div class="signup-link">
                <p>Don't have an account? <a href="signup.php">Sign up</a></p>
            </div>
        </div>
    </section>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
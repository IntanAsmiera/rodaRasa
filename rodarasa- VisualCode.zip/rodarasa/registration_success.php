<?php
session_start();

// Redirect if not coming from successful signup
if (!isset($_SESSION['signup_success'])) {
    header('Location: signup.php');
    exit();
}

// Clear the session
unset($_SESSION['signup_success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Successful - Roda Rasa</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }
        
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .popup-content {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
            width: 90%;
        }
        
        .popup-content h2 {
            color: #4CAF50;
            margin-bottom: 1rem;
        }
        
        .popup-content p {
            margin-bottom: 1.5rem;
            color: #333;
        }
        
        .popup-content button {
            padding: 0.8rem 1.5rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .popup-content button:hover {
            background-color: #c0392b;
        }
    </style>
    <script>
        // Redirect after 3 seconds
        setTimeout(function() {
            window.location.href = 'login.php';
        }, 3000);
    </script>
</head>
<body>
    <div class="popup-overlay">
        <div class="popup-content">
            <h2>Registration Successful!</h2>
            <p>You will be redirected to the login page shortly.</p>
            <button onclick="window.location.href='login.php'">Go to Login Now</button>
        </div>
    </div>
</body>
</html>
<?php
// Get the page parameter from URL, default to 'home' if not set
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Database connection for all pages
$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch data based on page
    if ($page == 'admin_management') {
        $stmt = $pdo->query("SELECT * FROM admins ORDER BY registered_at DESC");
        $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($page == 'user_management') {
        $stmt = $pdo->query("SELECT * FROM users");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($page == 'truck_tracking') {
        $stmt = $pdo->query("
            SELECT t.*, u.full_name 
            FROM food_trucks t
            JOIN users u ON t.user_id = u.id
            ORDER BY t.reported_at DESC
        ");
        $trucks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roda Rasa - Food Truck Experience</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
            position: relative;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        
        nav ul li a:hover {
            border-bottom: 2px solid white;
        }
        
        /* Dropdown menu styles */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            left: 0;
            top: 100%;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        nav ul li:hover .dropdown-content {
            display: block;
        }
        
        .hero {
            min-height: 100vh;
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), 
                      url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            text-align: center;
        }

        .hero h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.6);
        }

        .hero p {
            font-size: 1.8rem;
            max-width: 800px;
            margin: 0 auto;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.6);
        }

        /* Form styles */
        .form-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            color: #333;
        }
        
        .form-container h2 {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .form-container input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 1.2rem;
            box-sizing: border-box;
        }
        
        .form-container button[type="submit"] {
            width: 100%;
            padding: 1rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .form-container button[type="submit"]:hover {
            background-color: #c0392b;
        }
        
        .login-link, .signup-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #666;
        }
        
        .login-link a, .signup-link a {
            color: #e74c3c;
            font-weight: bold;
            text-decoration: none;
        }

        /* Content section styles */
        .content-section {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 90%;
            max-width: 1200px;
            margin: 2rem auto;
            color: #333;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #e74c3c;
            color: white;
        }
        
        tr:hover {
            background-color: #f5f5f5;
        }

        .action-buttons a {
            padding: 5px 10px;
            margin: 0 5px;
            text-decoration: none;
            border-radius: 3px;
            font-size: 0.9rem;
        }
        
        .edit-btn {
            background-color: #3498db;
            color: white;
        }
        
        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }

        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: auto;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="dashboard.php?page=home">Home</a></li>
                <li>
                    <a href="#">Information</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=user_management">User</a>
                        <a href="dashboard.php?page=admin_management">Admin</a>
                    </div>
                </li>
                <li>
                    <a href="#">Food Truck</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=truck_tracking">Track Truck</a>
                    </div>
                </li>
                <li><a href="dashboard.php?page=signup">Sign Up</a></li>
                <li><a href="dashboard.php?page=login">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <section class="hero">
        <?php if ($page == 'signup'): ?>
            <!-- Signup Form Content -->
            <div class="form-container">
                <h2>Sign Up for Admin</h2>
                
                <form action="process_signup.php" method="POST">
                    <div>
                        <input type="text" id="name" name="name" placeholder="Full Name" required>
                    </div>
                    
                    <div>
                        <input type="email" id="email" name="email" placeholder="Email Address" required>
                    </div>
                    
                    <div>
                        <input type="tel" id="phone" name="phone" placeholder="Phone Number" required>
                    </div>
                    
                    <div>
                        <input type="password" id="password" name="password" placeholder="Password" required>
                    </div>
                    
                    <div>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                    </div>
                    
                    <button type="submit">Register Admin</button>
                </form>
                
                <div class="login-link">
                    <p>Already have an account? <a href="dashboard.php?page=login">Sign in</a></p>
                </div>
            </div>
        <?php elseif ($page == 'login'): ?>
            <!-- Login Form Content -->
            <div class="form-container">
                <h2>Login</h2>
                
                <form action="process_login.php" method="POST">
                    <div>
                        <input type="email" id="email" name="email" placeholder="Email Address" required>
                    </div>
                    
                    <div>
                        <input type="password" id="password" name="password" placeholder="Password" required>
                    </div>
                    
                    <button type="submit">Login</button>
                </form>
                
                <div class="signup-link">
                    <p>Don't have an account? <a href="dashboard.php?page=signup">Sign up</a></p>
                </div>
            </div>
        <?php elseif ($page == 'admin_management'): ?>
            <!-- Admin Management Content -->
            <div class="content-section">
                <h1>Admin Information</h1>
                
                <table>
                    <thead>
                        <tr>
                            <th>Admin ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Registered At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($admins as $admin): ?>
                        <tr>
                            <td><?= htmlspecialchars($admin['id']) ?></td>
                            <td><?= htmlspecialchars($admin['full_name']) ?></td>
                            <td><?= htmlspecialchars($admin['email']) ?></td>
                            <td><?= htmlspecialchars($admin['registered_at']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($page == 'user_management'): ?>
            <!-- User Management Content -->
            <div class="content-section">
                <h1>User Information</h1>
                
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Coordinate (Lat, Lng)</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= htmlspecialchars($user['id']) ?></td>
                            <td><?= htmlspecialchars($user['full_name']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td><?= htmlspecialchars($user['address']) ?></td>
                            <td><?= htmlspecialchars($user['latitude']) ?>, <?= htmlspecialchars($user['longitude']) ?></td>
                            <td><?= htmlspecialchars($user['created_at']) ?></td>
                            <td class="action-buttons">
                                <a href="edit_user.php?id=<?= $user['id'] ?>" class="edit-btn">Edit</a>
                                <a href="delete_user.php?id=<?= $user['id'] ?>" class="delete-btn">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($page == 'truck_tracking'): ?>
            <!-- Food Truck Tracking Content -->
            <div class="content-section">
                <h1>Tracked Food Truck Records</h1>
                
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User Full Name</th>
                            <th>Food Truck Name</th>
                            <th>Food Type</th>
                            <th>Latitude</th>
                            <th>Longitude</th>
                            <th>Reported At</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($trucks as $truck): ?>
                        <tr>
                            <td><?= htmlspecialchars($truck['id']) ?></td>
                            <td><?= htmlspecialchars($truck['full_name']) ?></td>
                            <td><?= htmlspecialchars($truck['truck_name']) ?></td>
                            <td><?= htmlspecialchars($truck['food_type']) ?></td>
                            <td><?= htmlspecialchars($truck['latitude']) ?></td>
                            <td><?= htmlspecialchars($truck['longitude']) ?></td>
                            <td><?= htmlspecialchars($truck['reported_at']) ?></td>
                            <td><?= htmlspecialchars($truck['created_at']) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <!-- Default Hero Content -->
            <h1>Welcome to Roda Rasa</h1>
            <p>Your premier food truck experience with real-time tracking and ordering</p>
        <?php endif; ?>
    </section>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
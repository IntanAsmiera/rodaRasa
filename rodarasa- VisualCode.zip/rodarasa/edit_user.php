<?php
// Database connection
$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch user data if ID is provided
    if(isset($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_GET['id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if(!$user) {
            die("User not found");
        }
    }
    
    // Handle form submission
    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['id'];
        $full_name = $_POST['full_name'];
        $email = $_POST['email'];
        $address = $_POST['address'];
        $latitude = $_POST['latitude'];
        $longitude = $_POST['longitude'];
        
        $stmt = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, address = ?, latitude = ?, longitude = ? WHERE id = ?");
        $stmt->execute([$full_name, $email, $address, $latitude, $longitude, $id]);
        
        header("Location: dashboard.php?page=user_management");
        exit();
    }
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Roda Rasa</title>
    <style>
        /* Main styles matching your other pages */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
            background-image: url('your-background-image.jpg'); /* Add your background image */
            background-size: cover;
            background-attachment: fixed;
            background-position: center;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
            position: relative;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        
        nav ul li a:hover {
            border-bottom: 2px solid white;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            left: 0;
            top: 100%;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        nav ul li:hover .dropdown-content {
            display: block;
        }
        
        /* Content Section Styles */
        .content-section {
            padding: 3rem 2rem;
            max-width: 800px;
            margin: 2rem auto;
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        /* Form Styles */
        .edit-form {
            margin-top: 2rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #333;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input[type="text"]:focus,
        .form-group input[type="email"]:focus {
            border-color: #3498db;
            outline: none;
        }
        
        .submit-btn {
            background-color: #3498db;
            color: white;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }
        
        .submit-btn:hover {
            background-color: #2980b9;
        }
        
        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="dashboard.php?page=home">Home</a></li>
                <li>
                    <a href="#">Information</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=user_management">User</a>
                        <a href="dashboard.php?page=admin_management">Admin</a>
                    </div>
                </li>
                <li>
                    <a href="#">Food Truck</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=truck_tracking">Track Truck</a>
                    </div>
                </li>
                <li><a href="dashboard.php?page=signup">Sign Up</a></li>
                <li><a href="dashboard.php?page=login">Login</a></li>
            </ul>
        </nav>
    </header>

    <div class="content-section">
        <h1>Edit User</h1>
        
        <form method="POST" class="edit-form">
            <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">
            
            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($user['full_name']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" value="<?= htmlspecialchars($user['address']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="latitude">Latitude</label>
                <input type="text" id="latitude" name="latitude" value="<?= htmlspecialchars($user['latitude']) ?>" required>
            </div>
            
            <div class="form-group">
                <label for="longitude">Longitude</label>
                <input type="text" id="longitude" name="longitude" value="<?= htmlspecialchars($user['longitude']) ?>" required>
            </div>
            
            <button type="submit" class="submit-btn">Update User</button>
        </form>
    </div>

    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
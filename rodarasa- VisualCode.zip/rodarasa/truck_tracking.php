<?php
// Database connection
$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch food truck records
    $stmt = $pdo->query("
        SELECT t.*, u.full_name 
        FROM food_trucks t
        JOIN users u ON t.user_id = u.id
        ORDER BY t.reported_at DESC
    ");
    $trucks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tracked Food Trucks - Roda Rasa</title>
    <style>
        /* EXACTLY THE SAME STYLES AS DASHBOARD.PHP */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
            position: relative;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        
        nav ul li a:hover {
            border-bottom: 2px solid white;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            left: 0;
            top: 100%;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        nav ul li:hover .dropdown-content {
            display: block;
        }
        
        /* Content Section Styles */
        .content-section {
            padding: 3rem 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #e74c3c;
            color: white;
        }
        
        tr:hover {
            background-color: #f5f5f5;
        }
        
        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- EXACT SAME HEADER AS DASHBOARD.PHP -->
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="dashboard.php?page=home">Home</a></li>
                <li>
                    <a href="#">Information</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=user_management">User</a>
                        <a href="dashboard.php?page=admin_management">Admin</a>
                    </div>
                </li>
                <li>
                    <a href="#">Food Truck</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=truck_tracking">Track Truck</a>
                    </div>
                </li>
                <li><a href="dashboard.php?page=signup">Sign Up</a></li>
                <li><a href="dashboard.php?page=login">Login</a></li>
            </ul>
        </nav>
    </header>

    <!-- Content Section -->
    <div class="content-section">
        <h1>Tracked Food Truck Records</h1>
        
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Full Name</th>
                    <th>Food Truck Name</th>
                    <th>Food Type</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Reported At</th>
                    <th>Created At</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($trucks as $truck): ?>
                <tr>
                    <td><?= htmlspecialchars($truck['id']) ?></td>
                    <td><?= htmlspecialchars($truck['full_name']) ?></td>
                    <td><?= htmlspecialchars($truck['truck_name']) ?></td>
                    <td><?= htmlspecialchars($truck['food_type']) ?></td>
                    <td><?= htmlspecialchars($truck['latitude']) ?></td>
                    <td><?= htmlspecialchars($truck['longitude']) ?></td>
                    <td><?= htmlspecialchars($truck['reported_at']) ?></td>
                    <td><?= htmlspecialchars($truck['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- EXACT SAME FOOTER AS DASHBOARD.PHP -->
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
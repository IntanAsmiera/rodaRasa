<?php
// Database connection
$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch users
    $stmt = $pdo->query("SELECT * FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Roda Rasa</title>
    <style>
        /* EXACTLY THE SAME STYLES AS DASHBOARD.PHP */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
            position: relative;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            transition: all 0.3s ease;
            border-bottom: 2px solid transparent;
        }
        
        nav ul li a:hover {
            border-bottom: 2px solid white;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            left: 0;
            top: 100%;
        }
        
        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        nav ul li:hover .dropdown-content {
            display: block;
        }
        
        /* Content Section Styles */
        .content-section {
            padding: 3rem 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1.5rem;
            box-shadow: 0 2px 3px rgba(0,0,0,0.1);
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #e74c3c;
            color: white;
        }
        
        tr:hover {
            background-color: #f5f5f5;
        }
        
        .action-buttons a {
            padding: 5px 10px;
            margin: 0 5px;
            text-decoration: none;
            border-radius: 3px;
            font-size: 0.9rem;
        }
        
        .edit-btn {
            background-color: #3498db;
            color: white;
        }
        
        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }
        
        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: 2rem;
        }
    </style>
</head>
<body>
    <!-- EXACT SAME HEADER AS DASHBOARD.PHP -->
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="dashboard.php?page=home">Home</a></li>
                <li>
                    <a href="#">Information</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=user_management">User</a>
                        <a href="dashboard.php?page=admin_management">Admin</a>
                    </div>
                </li>
                <li>
                    <a href="#">Food Truck</a>
                    <div class="dropdown-content">
                        <a href="dashboard.php?page=truck_info">Information</a>
                        <a href="dashboard.php?page=truck_tracking">Track Truck</a>
                    </div>
                </li>
                <li><a href="dashboard.php?page=signup">Sign Up</a></li>
                <li><a href="dashboard.php?page=login">Login</a></li>
            </ul>
        </nav>
    </header>

    <!-- Content Section -->
    <div class="content-section">
        <h1>Roda Rasa Admin</h1>
        <h2>Information</h2>
        
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Address</th>
                    <th>Coordinate (Lat, Lng)</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= htmlspecialchars($user['id']) ?></td>
                    <td><?= htmlspecialchars($user['full_name']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= htmlspecialchars($user['address']) ?></td>
                    <td><?= htmlspecialchars($user['latitude']) ?>, <?= htmlspecialchars($user['longitude']) ?></td>
                    <td><?= htmlspecialchars($user['created_at']) ?></td>
                    <td class="action-buttons">
                        <a href="edit_user.php?id=<?= $user['id'] ?>" class="edit-btn">Edit</a>
                        <a href="delete_user.php?id=<?= $user['id'] ?>" class="delete-btn">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- EXACT SAME FOOTER AS DASHBOARD.PHP -->
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
<?php
// Database connection
$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    if(isset($_GET['id'])) {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
        $stmt->execute([$_GET['id']]);
    }
    
    header("Location: dashboard.php?page=user_management");
    exit();
} catch(PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
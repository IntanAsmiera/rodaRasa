<?php
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo json_encode([
        "status" => false,
        "message" => "Database connection failed: " . $e->getMessage()
    ]);
    exit;
}

try {
    $stmt = $pdo->query("
        SELECT 
            t.truck_name,
            t.food_type,
            t.latitude,
            t.longitude,
            t.reported_at,
            COALESCE(u.full_name, 'Unknown') AS reported_by
        FROM food_trucks t
        LEFT JOIN users u ON t.user_id = u.id
        ORDER BY t.reported_at DESC
    ");

    $trucks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => true,
        "data" => $trucks
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status" => false,
        "message" => "Error fetching data: " . $e->getMessage()
    ]);
}
?>

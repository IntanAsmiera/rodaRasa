<?php 
header('Content-Type: application/json');

$host = 'localhost';
$dbname = 'roda_rasa';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["status" => false, "message" => "Database error: " . $e->getMessage()]);
    exit;
}

if (
    isset($_POST['truck_name']) &&
    isset($_POST['food_type']) &&
    isset($_POST['latitude']) &&
    isset($_POST['longitude']) &&
    isset($_POST['reported_at']) &&
    isset($_POST['created_at']) &&
    isset($_POST['user_id']) // still required if you want to track or validate user
) {
    try {
        $stmt = $pdo->prepare("INSERT INTO food_trucks (truck_name, food_type, latitude, longitude, reported_at, created_at, user_id)
                       VALUES (?, ?, ?, ?, ?, ?, ?)");

$stmt->execute([
    $_POST['truck_name'],
    $_POST['food_type'],
    $_POST['latitude'],
    $_POST['longitude'],
    $_POST['reported_at'],
    $_POST['created_at'],
    $_POST['user_id']
]);

        echo json_encode(["status" => true, "message" => "Food truck reported successfully."]);
    } catch (PDOException $e) {
        echo json_encode(["status" => false, "message" => "Insert failed: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Missing required fields."]);
}

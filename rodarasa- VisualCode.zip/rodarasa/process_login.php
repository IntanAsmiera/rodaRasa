<?php
session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Add your authentication logic here (check against database)
    // For example:
    $valid_email = 'ahmad@gmail.com';
    $valid_password_hash = password_hash('yourpassword', PASSWORD_DEFAULT); // In real app, this comes from DB
    
    if ($email === $valid_email && password_verify('yourpassword', $valid_password_hash)) {
        // Login successful
        $_SESSION['logged_in'] = true;
        $_SESSION['user_email'] = $email;
        header('Location: dashboard.php');
        exit();
    } else {
        // Login failed
        $_SESSION['login_errors'] = ['Invalid email or password'];
        header('Location: login.php');
        exit();
    }
}
?>
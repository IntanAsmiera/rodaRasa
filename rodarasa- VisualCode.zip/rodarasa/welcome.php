<?php
// Get the page parameter from URL, default to 'home' if not set
$page = isset($_GET['page']) ? $_GET['page'] : 'home';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roda Rasa - Food Truck Experience</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            line-height: 1.6;
            background-color: #f9f9f9;
        }
        
        header {
            background-color: #e74c3c;
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: white;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 1.5rem;
            position: relative;
        }
        
        nav ul li a {
            color: rgba(255, 255, 255, 0.5);
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 0;
            border-bottom: 2px solid transparent;
            cursor: default;
            pointer-events: none;
        }
        
        nav ul li a.active {
            color: white;
            cursor: pointer;
            pointer-events: auto;
        }
        
        .hero {
            height: 100vh;
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), 
                      url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            text-align: center;
        }

        .hero h1 {
            font-size: 4rem;
            margin-bottom: 1rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.6);
        }

        .hero p {
            font-size: 1.8rem;
            max-width: 800px;
            margin: 0 auto;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.6);
        }

        /* Form styles */
        .form-container {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            color: #333;
        }
        
        .form-container h2 {
            color: #e74c3c;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .form-container input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 1.2rem;
            box-sizing: border-box;
        }
        
        .form-container button[type="submit"] {
            width: 100%;
            padding: 1rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .form-container button[type="submit"]:hover {
            background-color: #c0392b;
        }
        
        .login-link, .signup-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #666;
        }
        
        .login-link a, .signup-link a {
            color: #e74c3c;
            font-weight: bold;
            text-decoration: none;
        }

        footer {
            background-color: #e74c3c;
            color: white;
            text-align: center;
            padding: 1.5rem;
            margin-top: 0;
        }

        /* Popup styles */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .popup-content {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        
        .popup-content h2 {
            color: #4CAF50;
            margin-bottom: 1rem;
        }
        
        .popup-content p {
            margin-bottom: 1.5rem;
        }
        
        .popup-content button {
            padding: 0.8rem 1.5rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="#" class="inactive">Home</a></li>
                <li><a href="#" class="inactive">Information</a></li>
                <li><a href="#" class="inactive">Food Truck</a></li>
                <li><a href="welcome.php?page=signup" class="active">Sign Up</a></li>
                <li><a href="welcome.php?page=login" class="active">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <section class="hero">
        <?php if ($page == 'signup'): ?>
            <!-- Signup Form Content -->
            <div class="form-container">
                <h2>Sign Up for Admin</h2>
                
                <?php if (isset($_SESSION['signup_errors'])): ?>
                    <div class="error-message">
                        <?php foreach ($_SESSION['signup_errors'] as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                        <?php unset($_SESSION['signup_errors']); ?>
                    </div>
                <?php endif; ?>
                
                <form action="process_signup.php" method="POST">
                    <div>
                        <input type="text" id="name" name="name" placeholder="Full Name" required>
                    </div>
                    
                    <div>
                        <input type="email" id="email" name="email" placeholder="Email Address" required>
                    </div>
                    
                    <div>
                        <input type="tel" id="phone" name="phone" placeholder="Phone Number" required>
                    </div>
                    
                    <div>
                        <input type="password" id="password" name="password" placeholder="Password" required>
                    </div>
                    
                    <div>
                        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                    </div>
                    
                    <button type="submit">Register Admin</button>
                </form>
                
                <div class="login-link">
                    <p>Already have an account? <a href="welcome.php?page=login">Sign in</a></p>
                </div>
            </div>
        <?php elseif ($page == 'login'): ?>
            <!-- Login Form Content -->
            <div class="form-container">
                <h2>Login</h2>
                
                <form action="process_login.php" method="POST">
                    <div>
                        <input type="email" id="email" name="email" placeholder="Email Address" required>
                    </div>
                    
                    <div>
                        <input type="password" id="password" name="password" placeholder="Password" required>
                    </div>
                    
                    <button type="submit">Login</button>
                </form>
                
                <div class="signup-link">
                    <p>Don't have an account? <a href="welcome.php?page=signup">Sign up</a></p>
                </div>
            </div>
        <?php else: ?>
            <!-- Default Hero Content -->
            <h1>Welcome to Roda Rasa</h1>
            <p>Your premier food truck experience with real-time tracking and ordering</p>
        <?php endif; ?>
    </section>
    
    <?php if (isset($_SESSION['signup_success'])): ?>
        <div class="popup-overlay">
            <div class="popup-content">
                <h2>Registration Successful!</h2>
                <p>You will be redirected to the login page shortly.</p>
                <button onclick="window.location.href='welcome.php?page=login'">Go to Login</button>
            </div>
        </div>
        <script>
            setTimeout(function() {
                window.location.href = 'welcome.php?page=login';
            }, 3000);
        </script>
        <?php unset($_SESSION['signup_success']); ?>
    <?php endif; ?>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>
</body>
</html>
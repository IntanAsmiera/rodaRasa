<?php
$host = 'localhost';
$dbname = 'roda_rasa';
$dbuser = 'root';
$dbpass = '';
$pdo = null;
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    $errors = [];

    if (empty($name)) $errors[] = "Name is required";
    if (empty($email)) $errors[] = "Email is required";
    if (empty($password)) $errors[] = "Password is required";
    if ($password !== $confirm_password) $errors[] = "Passwords don't match";

    if (empty($errors)) {
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $dbuser, $dbpass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("INSERT INTO users (full_name, email, phone, password) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $hashedPassword]);

            $success = true;
        } catch (PDOException $e) {
            $errors[] = "Database error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Roda Rasa</title>
    <style>
        /* Your existing styles remain the same */
        
        /* Add these new styles for the popup */
        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        
        .popup-content {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        
        .popup-content h2 {
            color: #4CAF50;
            margin-bottom: 1rem;
        }
        
        .popup-content p {
            margin-bottom: 1.5rem;
        }
        
        .popup-content button {
            padding: 0.8rem 1.5rem;
            background-color: #e74c3c;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
        }

        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Roda Rasa</div>
        <nav>
            <ul>
                <li><a href="dashboard.php?page=home">Home</a></li>
                <li><a href="dashboard.php?page=menu">Information</a></li>
                <li><a href="dashboard.php?page=home">Food Truck</a></li>
                <li><a href="dashboard.php?page=home">Sign Up</a></li>
                <li><a href="dashboard.php?page=home">Login</a></li>
            </ul>
        </nav>
    </header>
    
    <!-- Hero Section with Background Image and Form Overlay -->
    <section class="hero">
        <div class="form-container">
            <h2>Sign Up for Admin</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $error): ?>
                        <p><?php echo htmlspecialchars($error); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form id="signupForm" action="signup.php" method="POST">
                <div>
                    <input type="text" id="name" name="name" placeholder="Full Name" required value="<?php echo htmlspecialchars($name ?? ''); ?>">
                </div>
                
                <div>
                    <input type="email" id="email" name="email" placeholder="Email Address" required value="<?php echo htmlspecialchars($email ?? ''); ?>">
                </div>
                
                <div>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                
                <div>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
                </div>
                
                <button type="submit">Register Admin</button>
            </form>
            
            <div class="login-link">
                <p>Already have an account? <a href="dashboard.php?page=login">Sign in</a></p>
            </div>
        </div>
    </section>
    
    <!-- Success Popup -->
    <?php if (isset($success) && $success): ?>
    <div class="popup-overlay" id="successPopup">
        <div class="popup-content">
            <h2>Registration Successful!</h2>
            <p>You can now login with your credentials.</p>
            <button onclick="window.location.href='dashboard.php?page=login'">Go to Login</button>
        </div>
    </div>
    <?php endif; ?>
    
    <footer>
        &copy; <?php echo date("Y"); ?> Roda Rasa. All rights reserved.
    </footer>

    <script>
        // Show popup if success
        <?php if (isset($success) && $success): ?>
            document.addEventListener('DOMContentLoaded', function() {
                document.getElementById('successPopup').style.display = 'flex';
            });
        <?php endif; ?>

        // Optional: Auto-redirect after 3 seconds
        <?php if (isset($success) && $success): ?>
            setTimeout(function() {
                window.location.href = 'dashboard.php?page=login';
            }, 3000);
        <?php endif; ?>
    </script>
</body>
</html>
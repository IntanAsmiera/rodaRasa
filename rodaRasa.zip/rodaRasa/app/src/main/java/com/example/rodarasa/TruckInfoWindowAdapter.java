package com.example.rodarasa;

import android.app.Activity;
import android.view.View;
import android.view.LayoutInflater;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.Marker;

public class TruckInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {

    private final View view;

    public TruckInfoWindowAdapter(Activity context) {
        view = LayoutInflater.from(context).inflate(R.layout.info_window, null);
    }

    @Override
    public View getInfoWindow(Marker marker) {
        render(marker);
        return view;
    }

    @Override
    public View getInfoContents(Marker marker) {
        return null;
    }

    private void render(Marker marker) {
        TextView title = view.findViewById(R.id.title);
        TextView snippet = view.findViewById(R.id.snippet);

        title.setText(marker.getTitle());
        snippet.setText(marker.getSnippet());
    }
}

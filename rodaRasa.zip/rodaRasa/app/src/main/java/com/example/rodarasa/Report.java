package com.example.rodarasa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.rodarasa.model.ReportedTruck;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Report extends AppCompatActivity {

    private EditText truckNameInput, foodTypeInput, latitudeInput, longitudeInput;
    private EditText reportedAtInput, createdAtInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reportform);

        truckNameInput = findViewById(R.id.FoodTruckInput);
        foodTypeInput = findViewById(R.id.FoodTypeInput);
        latitudeInput = findViewById(R.id.LatitudeInput);
        longitudeInput = findViewById(R.id.LongitudeInput);
        reportedAtInput = findViewById(R.id.ReportAtDate);
        createdAtInput = findViewById(R.id.CreatedAtTime);

        Button submitButton = findViewById(R.id.btnSubmit);

        submitButton.setOnClickListener(view -> {
            String truckName = truckNameInput.getText().toString().trim();
            String foodType = foodTypeInput.getText().toString().trim();
            String latitude = latitudeInput.getText().toString().trim();
            String longitude = longitudeInput.getText().toString().trim();
            String reportedAt = reportedAtInput.getText().toString().trim();
            String createdAt = createdAtInput.getText().toString().trim();

            if (truckName.isEmpty() || foodType.isEmpty() || latitude.isEmpty() || longitude.isEmpty()) {
                Toast.makeText(Report.this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
            } else {
                sendTruckData(truckName, foodType, latitude, longitude, reportedAt, createdAt);
            }
        });
    }

    private void sendTruckData(String truckName, String foodType, String latitude, String longitude, String reportedAt, String createdAt) {
        String url = "http://10.0.2.2/ICT602/rodarasa/submit_truck.php";

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject json = new JSONObject(response);
                        boolean status = json.getBoolean("status");
                        String message = json.getString("message");

                        Toast.makeText(Report.this, message, Toast.LENGTH_LONG).show();

                        if (status) {
                            // ✅ Save to SharedPreferences for history
                            SharedPreferences sharedPreferences = getSharedPreferences("RodaRasaPrefs", MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();

                            Gson gson = new Gson();
                            Type type = new TypeToken<List<ReportedTruck>>() {}.getType();
                            String existingJson = sharedPreferences.getString("reported_trucks_history", null);
                            List<ReportedTruck> history = existingJson == null ? new ArrayList<>() : gson.fromJson(existingJson, type);

                            String nameType = truckName + " - " + foodType;
                            ReportedTruck newTruck = new ReportedTruck(nameType, reportedAt);
                            history.add(newTruck);

                            String updatedJson = gson.toJson(history);
                            editor.putString("reported_trucks_history", updatedJson);
                            editor.apply();

                            // ✅ Go to MapsActivity
                            Intent intent = new Intent(Report.this, MapsActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    } catch (Exception e) {
                        Toast.makeText(Report.this, "Error parsing response", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                },
                error -> {
                    Toast.makeText(Report.this, "Failed to connect. Check server.", Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                }) {

            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                String userId = sharedPreferences.getString("user_id", "0");

                Map<String, String> params = new HashMap<>();
                params.put("truck_name", truckName);
                params.put("food_type", foodType);
                params.put("latitude", latitude);
                params.put("longitude", longitude);
                params.put("reported_at", reportedAt);
                params.put("created_at", createdAt);
                params.put("user_id", "1");
                return params;
            }
        };

        queue.add(stringRequest);
    }
}

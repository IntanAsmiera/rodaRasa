package com.example.rodarasa;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnAboutUs = findViewById(R.id.btnAboutUs);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btnMaps = findViewById(R.id.btnMaps);

        btnAboutUs.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, AboutUsActivity.class));
        });

        btnMaps.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, MapsActivity.class));
        });

        // Inside onCreate of MainActivity.java (or your home activity)
        Button btnReportForm = findViewById(R.id.btnReportForm); // use your actual ID
        btnReportForm.setOnClickListener(view -> {
            Intent intent = new Intent(HomeActivity.this, Report.class); // Start Report activity
            startActivity(intent);
        });

        Button profileButton = findViewById(R.id.btnProfile);
        profileButton.setOnClickListener(v -> {
            // Get the email passed from MainActivity
            String userEmail = getIntent().getStringExtra("USER_EMAIL");

            Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
            intent.putExtra("USER_EMAIL", userEmail); // Forward email to ProfileActivity
            startActivity(intent);
        });



    }
}
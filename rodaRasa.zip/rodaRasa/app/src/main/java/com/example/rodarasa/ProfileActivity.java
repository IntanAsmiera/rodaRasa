package com.example.rodarasa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.rodarasa.model.ReportedTruck;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    private static final String TAG = "ProfileActivity";
    private static final String PREFS_NAME = "RodaRasaPrefs";
    private static final String KEY_REPORTED_TRUCKS = "reported_trucks_history";

    private TextView userNameTextView;
    private TextView reportedTrucksListTextView;
    private Button logoutButton;
    private SharedPreferences sharedPreferences;
    private Gson gson;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // Initialize Views
        userNameTextView = findViewById(R.id.userName);
        reportedTrucksListTextView = findViewById(R.id.reportedTrucksList);
        logoutButton = findViewById(R.id.logoutButton);

        // Initialize SharedPreferences and Gson
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        gson = new GsonBuilder().setPrettyPrinting().create();

        // Get the user email passed from HomeActivity (or elsewhere)
        String userEmail = getIntent().getStringExtra("USER_EMAIL");

        // Display the user's email in the TextView
        if (userEmail != null && !userEmail.trim().isEmpty()) {
            userNameTextView.setText("User ID: " + userEmail);
        } else {
            userNameTextView.setText("User ID: Not Available");
            Log.w(TAG, "USER_EMAIL not passed via Intent.");
        }

        // Load and display food truck report history
        displayReportedFoodTrucks();

        // Logout button behavior
        logoutButton.setOnClickListener(v -> {
            Toast.makeText(ProfileActivity.this, "Logging out...", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    /**
     * Retrieves and displays the list of reported food trucks.
     */
    private void displayReportedFoodTrucks() {
        List<ReportedTruck> history = getReportedTrucksHistory();
        if (history == null || history.isEmpty()) {
            reportedTrucksListTextView.setText("No food trucks reported yet.");
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < history.size(); i++) {
                ReportedTruck truck = history.get(i);
                sb.append(i + 1)
                        .append(". ")
                        .append(truck.getNameType())
                        .append(" (")
                        .append(truck.getReportedDate())
                        .append(")\n");
            }
            reportedTrucksListTextView.setText(sb.toString());
        }
    }

    /**
     * Loads the history from SharedPreferences using Gson.
     */
    private List<ReportedTruck> getReportedTrucksHistory() {
        String json = sharedPreferences.getString(KEY_REPORTED_TRUCKS, null);
        if (json == null || json.isEmpty()) {
            return new ArrayList<>();
        }

        Type type = new TypeToken<List<ReportedTruck>>() {}.getType();
        try {
            return gson.fromJson(json, type);
        } catch (Exception e) {
            Log.e(TAG, "Error parsing reported trucks JSON", e);
            return new ArrayList<>();
        }
    }
}

package com.example.rodarasa.model;

public class ReportedTruck {
    private String nameType;
    private String reportedDate;

    public ReportedTruck(String nameType, String reportedDate) {
        this.nameType = nameType;
        this.reportedDate = reportedDate;
    }

    public String getNameType() {
        return nameType;
    }

    public String getReportedDate() {
        return reportedDate;
    }
}

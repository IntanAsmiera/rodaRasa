package com.example.rodarasa;

import android.os.Bundle;
import android.util.Log; // ✅ Log import
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private static final LatLng MALAYSIA_CENTER = new LatLng(4.2105, 101.9758);
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Initialize ProgressBar
        progressBar = findViewById(R.id.progressBar);

        // Map fragment
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Optional: Manual reload button
        Button btnFind = findViewById(R.id.btnFindNearbyTrucks);
        btnFind.setOnClickListener(view -> loadFoodTrucks());
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(MALAYSIA_CENTER, 6f));
        mMap.setInfoWindowAdapter(new TruckInfoWindowAdapter(this));

        // Automatically load food trucks when map is ready
        loadFoodTrucks();
    }

    private void loadFoodTrucks() {
        String url = "http://10.0.2.2/ICT602/rodarasa/get_trucks.php";

        progressBar.setVisibility(View.VISIBLE); // Show loading spinner

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    progressBar.setVisibility(View.GONE); // Hide spinner

                    try {
                        boolean status = response.getBoolean("status");
                        if (!status) {
                            Toast.makeText(this, "No food trucks found", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        JSONArray trucks = response.getJSONArray("data");
                        mMap.clear(); // Clear previous markers

                        LatLngBounds.Builder boundsBuilder = new LatLngBounds.Builder(); // 🔄 Include all locations

                        for (int i = 0; i < trucks.length(); i++) {
                            JSONObject truck = trucks.getJSONObject(i);

                            String truckName = truck.getString("truck_name");
                            String foodType = truck.getString("food_type");
                            double lat = truck.getDouble("latitude");
                            double lng = truck.getDouble("longitude");
                            String reportedBy = truck.getString("reported_by");
                            String reportedAt = truck.getString("reported_at");

                            LatLng location = new LatLng(lat, lng);
                            mMap.addMarker(new MarkerOptions()
                                    .position(location)
                                    .title(truckName + " - " + foodType)
                                    .snippet("Reported by: " + reportedBy + "\nAt: " + reportedAt)
                                    .icon(getIconForFoodType(foodType))
                            );

                            boundsBuilder.include(location); // 🔄 include this marker
                        }

                        // 🗺 Zoom the map to show all markers
                        if (trucks.length() > 0) {
                            LatLngBounds bounds = boundsBuilder.build();
                            int padding = 120; // pixels
                            mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
                        }

                    } catch (JSONException e) {
                        Toast.makeText(this, "Error parsing truck data", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                        Log.e("VolleyParseError", "JSON Error: " + e.getMessage());
                    }
                },
                error -> {
                    progressBar.setVisibility(View.GONE); // Hide on failure too
                    Toast.makeText(this, "Failed to connect. Check internet or server.", Toast.LENGTH_LONG).show();
                    error.printStackTrace();
                    Log.e("VolleyError", "Error: " + error.toString());
                });

        queue.add(request);
    }


    private BitmapDescriptor getIconForFoodType(String foodType) {
        switch (foodType.toLowerCase()) {
            case "burger":
                return BitmapDescriptorFactory.fromResource(R.drawable.burger);
            case "coffee":
                return BitmapDescriptorFactory.fromResource(R.drawable.coffee);
            case "bbq":
                return BitmapDescriptorFactory.fromResource(R.drawable.bbq);
            // Add more food types as needed here
            default:
                return BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED);
        }
    }
}
